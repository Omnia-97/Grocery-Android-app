package com.mastercoding.marketapp;

import android.view.View;

public interface ItemClickListener {

    void onCLick(View v, int pos);
}
